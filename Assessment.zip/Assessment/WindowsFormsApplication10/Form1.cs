﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ConverterApp
// This program was written by Gail Mosdell
// It forms the base of a converter program for the OS-Assessment Two for Cert IV
// Date : February 2017
{
    public partial class frm_Main : Form
    {
        //Array declare, size is 5
        double[] arr = new double[5];
        int i = 0;

        public frm_Main()
        {
            InitializeComponent();
        }



        // input, output double
        double dbl_UofM, dbl_Convert;

        // making Exit button
        private void btn_Exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        //make saveArray for making easy
        public void saveArray(double value)
        {
            //giving for statument  i=order of array
            if (i < 5)
            {

                arr[i] = value;
                listBox1.Items.Add(arr[i]);
                i++;
            }
            // array is full show off messagebox "we already have 5 numbers"
            else
            {
                MessageBox.Show("We already have 5 numbers");
            }

        }    
        //making cm to inch button
        private void cm_to_inch_Click(object sender, EventArgs e)
        {
           //calculate 
            const double CM_TO_INCH = 0.3937;


            // if user don't put any input or not numeric show off messagebox "A numeric must be entered. Please re-enter the value."
            if (!double.TryParse(Input.Text, out dbl_UofM))
            {
                MessageBox.Show("A numeric must be entered. Please re-enter the value.");
                //clear input
                Input.Clear();
                //focus input
                Input.Focus();
             
            }
            else
            {
                dbl_Convert = dbl_UofM * CM_TO_INCH;
                saveArray(dbl_Convert);

                //listBox1.Text = dbl_Convert.ToString();

            }
        }
        // making meter to feet button 
        private void mt_to_feet_Click_1(object sender, EventArgs e)
        {

            const double mt_to_feet = 3.2808;

            if (!double.TryParse(Input.Text, out dbl_UofM))
            {
               
                Input.Clear();
                Input.Focus();
              
            }
            else

            {
                //input data * 3.2808
                dbl_Convert = dbl_UofM * mt_to_feet;
                //saving in saveArray
                saveArray(dbl_Convert);


            }
    
        }

        //making celsius to fahrenheit button
        private void cel_to_fah_Click(object sender, EventArgs e)
        {

            const double cel_to_fah = 33.8;

            if (!double.TryParse(Input.Text, out dbl_UofM))
            {
                MessageBox.Show("A numeric must be entered. Please re-enter the value.");
                Input.Clear();
                Input.Focus();
              
            }
            else
            {    
                //input * 33.8 + 32 because 0 celsius is 32 fahrenheit
                dbl_Convert = dbl_UofM * cel_to_fah+32;
                saveArray(dbl_Convert);
            }
        
        }
         //making cm to feet button
        private void cm_to_feet_Click_1(object sender, EventArgs e)
        {

            const double cm_to_feet = 0.0328;

            if (!double.TryParse(Input.Text, out dbl_UofM))
            {
                MessageBox.Show("A numeric must be entered. Please re-enter the value.");
                Input.Clear();
                Input.Focus();
            
            }
            else
            {
                dbl_Convert = dbl_UofM * cm_to_feet;
                saveArray(dbl_Convert);

            }
     
        }

        //making km to mile button
        private void km_to_mile_Click(object sender, EventArgs e)
        {

            const double km_to_mile = 0.6213;


            if (!double.TryParse(Input.Text, out dbl_UofM))
            {
                MessageBox.Show("A numeric must be entered. Please re-enter the value.");
                Input.Clear();
                Input.Focus();
                
            }
            else
            {
                dbl_Convert = dbl_UofM * km_to_mile;
                saveArray(dbl_Convert);


            }
        }
    }
}