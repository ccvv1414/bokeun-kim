﻿using System;

namespace ConverterApp
{
    partial class frm_Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Exit = new System.Windows.Forms.Button();
            this.cm_to_inch = new System.Windows.Forms.Button();
            this.km_to_mile = new System.Windows.Forms.Button();
            this.cm_to_feet = new System.Windows.Forms.Button();
            this.cel_to_fah = new System.Windows.Forms.Button();
            this.mt_to_feet = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.Input1 = new System.Windows.Forms.GroupBox();
            this.Input = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Input1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_Exit
            // 
            this.btn_Exit.Location = new System.Drawing.Point(349, 86);
            this.btn_Exit.Name = "btn_Exit";
            this.btn_Exit.Size = new System.Drawing.Size(91, 45);
            this.btn_Exit.TabIndex = 9;
            this.btn_Exit.Text = "Exit";
            this.btn_Exit.UseVisualStyleBackColor = true;
            this.btn_Exit.Click += new System.EventHandler(this.btn_Exit_Click);
            // 
            // cm_to_inch
            // 
            this.cm_to_inch.Location = new System.Drawing.Point(45, 29);
            this.cm_to_inch.Name = "cm_to_inch";
            this.cm_to_inch.Size = new System.Drawing.Size(260, 27);
            this.cm_to_inch.TabIndex = 10;
            this.cm_to_inch.Text = "Convert Centimetres to Inches";
            this.cm_to_inch.UseVisualStyleBackColor = true;
            this.cm_to_inch.Click += new System.EventHandler(this.cm_to_inch_Click);
            // 
            // km_to_mile
            // 
            this.km_to_mile.Location = new System.Drawing.Point(45, 161);
            this.km_to_mile.Name = "km_to_mile";
            this.km_to_mile.Size = new System.Drawing.Size(260, 27);
            this.km_to_mile.TabIndex = 11;
            this.km_to_mile.Text = "Convert Kilometres to Miles";
            this.km_to_mile.UseVisualStyleBackColor = true;
            this.km_to_mile.Click += new System.EventHandler(this.km_to_mile_Click);
            // 
            // cm_to_feet
            // 
            this.cm_to_feet.Location = new System.Drawing.Point(45, 128);
            this.cm_to_feet.Name = "cm_to_feet";
            this.cm_to_feet.Size = new System.Drawing.Size(260, 27);
            this.cm_to_feet.TabIndex = 12;
            this.cm_to_feet.Text = "Convert Centimetres to Feet";
            this.cm_to_feet.UseVisualStyleBackColor = true;
            this.cm_to_feet.Click += new System.EventHandler(this.cm_to_feet_Click_1);
            // 
            // cel_to_fah
            // 
            this.cel_to_fah.Location = new System.Drawing.Point(45, 95);
            this.cel_to_fah.Name = "cel_to_fah";
            this.cel_to_fah.Size = new System.Drawing.Size(260, 27);
            this.cel_to_fah.TabIndex = 13;
            this.cel_to_fah.Text = "Convert Celsius to Fahrenheit";
            this.cel_to_fah.UseVisualStyleBackColor = true;
            this.cel_to_fah.Click += new System.EventHandler(this.cel_to_fah_Click);
            // 
            // mt_to_feet
            // 
            this.mt_to_feet.Location = new System.Drawing.Point(45, 62);
            this.mt_to_feet.Name = "mt_to_feet";
            this.mt_to_feet.Size = new System.Drawing.Size(260, 27);
            this.mt_to_feet.TabIndex = 14;
            this.mt_to_feet.Text = "Convert Metres to Feet ";
            this.mt_to_feet.UseVisualStyleBackColor = true;
            this.mt_to_feet.Click += new System.EventHandler(this.mt_to_feet_Click_1);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(6, 12);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(439, 147);
            this.listBox1.TabIndex = 15;
            // 
            // Input1
            // 
            this.Input1.Controls.Add(this.Input);
            this.Input1.Location = new System.Drawing.Point(22, 209);
            this.Input1.Name = "Input1";
            this.Input1.Size = new System.Drawing.Size(445, 54);
            this.Input1.TabIndex = 16;
            this.Input1.TabStop = false;
            this.Input1.Text = "Input";
        //    this.Input1.Enter += new System.EventHandler(this.Input1_Enter);
            // 
            // Input
            // 
            this.Input.Location = new System.Drawing.Point(10, 19);
            this.Input.Multiline = true;
            this.Input.Name = "Input";
            this.Input.Size = new System.Drawing.Size(429, 26);
            this.Input.TabIndex = 0;
       //     this.Input.TextChanged += new System.EventHandler(this.Input_TextChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.listBox1);
            this.groupBox1.Location = new System.Drawing.Point(22, 269);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(451, 175);
            this.groupBox1.TabIndex = 18;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Output";
            // 
            // frm_Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(485, 446);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.Input1);
            this.Controls.Add(this.mt_to_feet);
            this.Controls.Add(this.cel_to_fah);
            this.Controls.Add(this.cm_to_feet);
            this.Controls.Add(this.km_to_mile);
            this.Controls.Add(this.cm_to_inch);
            this.Controls.Add(this.btn_Exit);
            this.Name = "frm_Main";
            this.Text = "ATCA Gas";
            //this.Load += new System.EventHandler(this.cm_to_inch_Click);
            this.Input1.ResumeLayout(false);
            this.Input1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        #endregion
        private System.Windows.Forms.Button btn_Exit;
        private System.Windows.Forms.Button cm_to_inch;
        private System.Windows.Forms.Button km_to_mile;
        private System.Windows.Forms.Button cm_to_feet;
        private System.Windows.Forms.Button cel_to_fah;
        private System.Windows.Forms.Button mt_to_feet;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.GroupBox Input1;
        private System.Windows.Forms.TextBox Input;
        private System.Windows.Forms.GroupBox groupBox1;

        public EventHandler input1_TextChanged { get; private set; }
    }
}

