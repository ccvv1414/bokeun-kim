﻿namespace FreelancerHub
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnFreelancers = new System.Windows.Forms.Button();
            this.btnFreelancersAndProjects = new System.Windows.Forms.Button();
            this.btnProjects = new System.Windows.Forms.Button();
            this.listBoxResults = new System.Windows.Forms.ListBox();
            this.lblStatus1 = new System.Windows.Forms.Label();
            this.lblError = new System.Windows.Forms.Label();
            this.txtFreelancerName = new System.Windows.Forms.TextBox();
            this.btnGetSingleFreelancer = new System.Windows.Forms.Button();
            this.btnAddFreelancer = new System.Windows.Forms.Button();
            this.btnUpdateFreelancer = new System.Windows.Forms.Button();
            this.btnDeleteFreelancer = new System.Windows.Forms.Button();
            this.btnTables = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnFreelancers
            // 
            this.btnFreelancers.Location = new System.Drawing.Point(63, 32);
            this.btnFreelancers.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnFreelancers.Name = "btnFreelancers";
            this.btnFreelancers.Size = new System.Drawing.Size(279, 59);
            this.btnFreelancers.TabIndex = 0;
            this.btnFreelancers.Text = "Freelancers";
            this.btnFreelancers.UseVisualStyleBackColor = true;
            this.btnFreelancers.Click += new System.EventHandler(this.btnFreelancers_Click);
            // 
            // btnFreelancersAndProjects
            // 
            this.btnFreelancersAndProjects.Location = new System.Drawing.Point(350, 32);
            this.btnFreelancersAndProjects.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnFreelancersAndProjects.Name = "btnFreelancersAndProjects";
            this.btnFreelancersAndProjects.Size = new System.Drawing.Size(288, 59);
            this.btnFreelancersAndProjects.TabIndex = 1;
            this.btnFreelancersAndProjects.Text = "Freelancers and Projects";
            this.btnFreelancersAndProjects.UseVisualStyleBackColor = true;
            this.btnFreelancersAndProjects.Click += new System.EventHandler(this.btnFreelancersAndProjects_Click);
            // 
            // btnProjects
            // 
            this.btnProjects.Location = new System.Drawing.Point(646, 32);
            this.btnProjects.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnProjects.Name = "btnProjects";
            this.btnProjects.Size = new System.Drawing.Size(287, 59);
            this.btnProjects.TabIndex = 2;
            this.btnProjects.Text = "Projects";
            this.btnProjects.UseVisualStyleBackColor = true;
            this.btnProjects.Click += new System.EventHandler(this.btnProjects_Click);
            // 
            // listBoxResults
            // 
            this.listBoxResults.FormattingEnabled = true;
            this.listBoxResults.ItemHeight = 15;
            this.listBoxResults.Location = new System.Drawing.Point(29, 250);
            this.listBoxResults.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.listBoxResults.Name = "listBoxResults";
            this.listBoxResults.Size = new System.Drawing.Size(917, 274);
            this.listBoxResults.TabIndex = 3;
            // 
            // lblStatus1
            // 
            this.lblStatus1.AutoSize = true;
            this.lblStatus1.Location = new System.Drawing.Point(134, 118);
            this.lblStatus1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblStatus1.Name = "lblStatus1";
            this.lblStatus1.Size = new System.Drawing.Size(49, 15);
            this.lblStatus1.TabIndex = 4;
            this.lblStatus1.Text = "Status";
            // 
            // lblError
            // 
            this.lblError.AutoSize = true;
            this.lblError.Location = new System.Drawing.Point(255, 118);
            this.lblError.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblError.Name = "lblError";
            this.lblError.Size = new System.Drawing.Size(37, 15);
            this.lblError.TabIndex = 5;
            this.lblError.Text = "Error";
            // 
            // txtFreelancerName
            // 
            this.txtFreelancerName.Location = new System.Drawing.Point(138, 151);
            this.txtFreelancerName.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtFreelancerName.Name = "txtFreelancerName";
            this.txtFreelancerName.Size = new System.Drawing.Size(203, 25);
            this.txtFreelancerName.TabIndex = 6;
            // 
            // btnGetSingleFreelancer
            // 
            this.btnGetSingleFreelancer.Location = new System.Drawing.Point(370, 149);
            this.btnGetSingleFreelancer.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnGetSingleFreelancer.Name = "btnGetSingleFreelancer";
            this.btnGetSingleFreelancer.Size = new System.Drawing.Size(268, 27);
            this.btnGetSingleFreelancer.TabIndex = 7;
            this.btnGetSingleFreelancer.Text = "Look up freelancer by last name";
            this.btnGetSingleFreelancer.UseVisualStyleBackColor = true;
            this.btnGetSingleFreelancer.Click += new System.EventHandler(this.btnGetSingleFreelancer_Click);
            // 
            // btnAddFreelancer
            // 
            this.btnAddFreelancer.Location = new System.Drawing.Point(370, 198);
            this.btnAddFreelancer.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnAddFreelancer.Name = "btnAddFreelancer";
            this.btnAddFreelancer.Size = new System.Drawing.Size(268, 26);
            this.btnAddFreelancer.TabIndex = 8;
            this.btnAddFreelancer.Text = "Add new Freelancer";
            this.btnAddFreelancer.UseVisualStyleBackColor = true;
            this.btnAddFreelancer.Click += new System.EventHandler(this.btnAddFreelancer_Click);
            // 
            // btnUpdateFreelancer
            // 
            this.btnUpdateFreelancer.Location = new System.Drawing.Point(94, 198);
            this.btnUpdateFreelancer.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnUpdateFreelancer.Name = "btnUpdateFreelancer";
            this.btnUpdateFreelancer.Size = new System.Drawing.Size(231, 26);
            this.btnUpdateFreelancer.TabIndex = 9;
            this.btnUpdateFreelancer.Text = "UpdateFreelancer";
            this.btnUpdateFreelancer.UseVisualStyleBackColor = true;
            this.btnUpdateFreelancer.Click += new System.EventHandler(this.btnUpdateFreelancer_Click);
            // 
            // btnDeleteFreelancer
            // 
            this.btnDeleteFreelancer.Location = new System.Drawing.Point(678, 198);
            this.btnDeleteFreelancer.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnDeleteFreelancer.Name = "btnDeleteFreelancer";
            this.btnDeleteFreelancer.Size = new System.Drawing.Size(238, 26);
            this.btnDeleteFreelancer.TabIndex = 10;
            this.btnDeleteFreelancer.Text = "DeleteFreelancer";
            this.btnDeleteFreelancer.UseVisualStyleBackColor = true;
            this.btnDeleteFreelancer.Click += new System.EventHandler(this.btnDeleteFreelancer_Click);
            // 
            // btnTables
            // 
            this.btnTables.Location = new System.Drawing.Point(29, 569);
            this.btnTables.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnTables.Name = "btnTables";
            this.btnTables.Size = new System.Drawing.Size(175, 67);
            this.btnTables.TabIndex = 11;
            this.btnTables.Text = "Data Editor";
            this.btnTables.UseVisualStyleBackColor = true;
            this.btnTables.Click += new System.EventHandler(this.btnTables_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1031, 757);
            this.Controls.Add(this.btnTables);
            this.Controls.Add(this.btnDeleteFreelancer);
            this.Controls.Add(this.btnUpdateFreelancer);
            this.Controls.Add(this.btnAddFreelancer);
            this.Controls.Add(this.btnGetSingleFreelancer);
            this.Controls.Add(this.txtFreelancerName);
            this.Controls.Add(this.lblError);
            this.Controls.Add(this.lblStatus1);
            this.Controls.Add(this.listBoxResults);
            this.Controls.Add(this.btnProjects);
            this.Controls.Add(this.btnFreelancersAndProjects);
            this.Controls.Add(this.btnFreelancers);
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnFreelancers;
        private System.Windows.Forms.Button btnFreelancersAndProjects;
        private System.Windows.Forms.Button btnProjects;
        private System.Windows.Forms.ListBox listBoxResults;
        private System.Windows.Forms.Label lblStatus1;
        private System.Windows.Forms.Label lblError;
        private System.Windows.Forms.TextBox txtFreelancerName;
        private System.Windows.Forms.Button btnGetSingleFreelancer;
        private System.Windows.Forms.Button btnAddFreelancer;
        private System.Windows.Forms.Button btnUpdateFreelancer;
        private System.Windows.Forms.Button btnDeleteFreelancer;
        private System.Windows.Forms.Button btnTables;
    }
}

