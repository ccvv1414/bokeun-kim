﻿using FreelancersDAL.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FreelancerHub
{
    public partial class DataTableForm : Form
    {
        private readonly IFreelancersService freelancersService;
        private DataSet dataSetFreelancers;

        public DataTableForm()
        {
            freelancersService = new FreelancersService();
            this.gridViewFreelancers = new DataGridView();

            InitializeComponent();
        }

        private void InitializeDataGrid()
        {
            try
            {
                dataSetFreelancers = freelancersService.GetDisconnectedData();

                this.gridViewFreelancers.DataSource = dataSetFreelancers.Tables["Freelancers"];
                this.gridViewFreelancers.DataMember = "Freelancers";
                gridViewFreelancers.Refresh();

            }

            catch(Exception ex)
            {
                // Error handling here.
            }


        }



        private void btnDashboard_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            InitializeDataGrid();
        }
    }
}
