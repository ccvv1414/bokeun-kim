﻿using MySql.Data.MySqlClient;
using FreelancersDAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace FreelancersDAL.Services
{
    public class ProjectsService : IProjectsService
    {

        string connectionString = ConfigurationManager.ConnectionStrings["FreelancersConnection"].ConnectionString.ToString();

        public List<Project> RetrieveProjects()
        {
                   List<Project> projects = new List<Project>();

            MySqlDataReader dataReader;

            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                MySqlCommand command =
                   new MySqlCommand("SELECT Id, Title, FreelancerId " + "FROM Projects ORDER BY Id;", conn);

                conn.Open();

                dataReader = command.ExecuteReader();

                if (dataReader.HasRows)
                {
                    while (dataReader.Read())
                    {
                        projects.Add(new Project
                            (
                            dataReader.GetInt32("Id"),
                            dataReader.GetString("Title"),
                            dataReader.GetInt32("FreelancerId")

                            ));

                    }
                }

                conn.Close();

            }
                return projects;
        }
    }




}
